import 'package:flutter/material.dart';
import '../services/account_api_service.dart';
import '../services/orders_api_service.dart';

class OrdersInfoForm extends StatefulWidget {
  const OrdersInfoForm({super.key});

  @override
  State<OrdersInfoForm> createState() => OrdersInfoFormState();
}

class OrdersInfoFormState extends State<OrdersInfoForm> {
  final _formKey = GlobalKey<FormState>();

  final _proveOfPaymentController = TextEditingController();

  DateTime? _paymentDateTime;

  List<AccountModel> _accounts = [];
  bool _loadingAccounts = false;
  int? _selectedAccountId;

  List<PaymentType> _paymentTypes = [];
  bool _loadingPaymentTypes = false;
  int? _selectedPaymentTypeId;

  List<OrderModel> _orders = [];
  bool _loadingOrders = false;

  bool _isSubmitting = false;

  bool _showingTable = false;
  int? _editingOrderId;

  final _orderSearchController = TextEditingController();
  List<OrderModel> _filteredOrders = [];
  int? _filterPaymentTypeId; // null = "All Payment Types"

  @override
  void initState() {
    super.initState();
    _loadAccounts();
    _loadPaymentTypes();
    _loadOrders();
  }

  @override
  void dispose() {
    _proveOfPaymentController.dispose();
    _orderSearchController.dispose();
    super.dispose();
  }

  // ---------------- loading ----------------

  Future<void> _loadAccounts() async {
    setState(() => _loadingAccounts = true);
    try {
      final accounts = await AccountApiService.getAllAccounts();
      if (!mounted) return;
      setState(() {
        _accounts = accounts;
        if (_selectedAccountId != null &&
            !_accounts.any((a) => a.id == _selectedAccountId)) {
          _selectedAccountId = null;
        }
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to load accounts: $e')),
      );
    } finally {
      if (mounted) setState(() => _loadingAccounts = false);
    }
  }

  Future<void> reloadAccounts() => _loadAccounts();

  Future<void> _loadPaymentTypes() async {
    setState(() => _loadingPaymentTypes = true);
    try {
      final types = await OrdersApiService.getAllPaymentTypes();
      if (!mounted) return;
      setState(() {
        _paymentTypes = types;
        if (_selectedPaymentTypeId != null &&
            !_paymentTypes.any((t) => t.id == _selectedPaymentTypeId)) {
          _selectedPaymentTypeId = null;
        }
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to load payment types: $e')),
      );
    } finally {
      if (mounted) setState(() => _loadingPaymentTypes = false);
    }
  }

  Future<void> reloadPaymentTypes() => _loadPaymentTypes();

  Future<void> _loadOrders() async {
    setState(() => _loadingOrders = true);
    try {
      final orders = await OrdersApiService.getAllOrders();
      if (!mounted) return;
      setState(() => _orders = orders);
      _applyFilters();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Failed to load orders: $e')));
    } finally {
      if (mounted) setState(() => _loadingOrders = false);
    }
  }

  Future<void> reloadOrders() => _loadOrders();

  // ---------------- helpers ----------------

  String _accountNameFor(int accountId) {
    final match = _accounts.where((a) => a.id == accountId);
    return match.isNotEmpty
        ? '${match.first.firstName} ${match.first.lastName}'
        : 'Account #$accountId';
  }

  String _paymentTypeNameFor(int? paymentTypeId) {
    if (paymentTypeId == null) return '-';
    final match = _paymentTypes.where((t) => t.id == paymentTypeId);
    return match.isNotEmpty ? match.first.paymentTypeName : 'Type #$paymentTypeId';
  }

  void _applyFilters() {
    final q = _orderSearchController.text.trim().toLowerCase();
    setState(() {
      _filteredOrders = _orders.where((order) {
        final matchesType = _filterPaymentTypeId == null ||
            order.paymentTypeId == _filterPaymentTypeId;
        final matchesQuery = q.isEmpty ||
            order.id.toString().contains(q) ||
            order.accountId.toString().contains(q) ||
            _accountNameFor(order.accountId).toLowerCase().contains(q);
        return matchesType && matchesQuery;
      }).toList();
    });
  }

  void _filterOrders(String query) => _applyFilters();

  Future<void> _onPaymentTypeFilterChanged(int? paymentTypeId) async {
    setState(() => _filterPaymentTypeId = paymentTypeId);
    _applyFilters();
  }

  void _openTable() {
    setState(() => _showingTable = true);
    _loadOrders();
  }

  String _two(int n) => n.toString().padLeft(2, '0');

  String _formatForApi(DateTime dt) =>
      '${dt.year}-${_two(dt.month)}-${_two(dt.day)} ${_two(dt.hour)}:${_two(dt.minute)}:00';

  String _formatForDisplay(DateTime? dt) {
    if (dt == null) return 'Tap to select (optional)';
    return '${dt.year}-${_two(dt.month)}-${_two(dt.day)}  ${_two(dt.hour)}:${_two(dt.minute)}';
  }

  Future<DateTime?> _pickDateTime(DateTime? initial) async {
    final now = DateTime.now();
    final date = await showDatePicker(
      context: context,
      initialDate: initial ?? now,
      firstDate: DateTime(now.year - 2),
      lastDate: DateTime(now.year + 5),
    );
    if (date == null || !mounted) return null;

    final time = await showTimePicker(
      context: context,
      initialTime: initial != null
          ? TimeOfDay.fromDateTime(initial)
          : TimeOfDay.now(),
    );
    if (time == null) return null;

    return DateTime(date.year, date.month, date.day, time.hour, time.minute);
  }

  Future<void> _pickPaymentDate() async {
    final picked = await _pickDateTime(_paymentDateTime);
    if (picked != null) setState(() => _paymentDateTime = picked);
  }

  void _clearPaymentDate() => setState(() => _paymentDateTime = null);

  Future<void> _openAccountPicker() async {
    final result = await showDialog<AccountModel>(
      context: context,
      builder: (context) => _AccountPickerDialog(accounts: _accounts),
    );
    if (result != null) {
      setState(() => _selectedAccountId = result.id);
    }
  }

  Future<void> _openPaymentTypePicker() async {
    final result = await showDialog<PaymentType>(
      context: context,
      builder: (context) => _PaymentTypePickerDialog(paymentTypes: _paymentTypes),
    );
    if (result != null) {
      setState(() => _selectedPaymentTypeId = result.id);
    }
  }

  Future<void> _openPaymentTypeFilterPicker() async {
    final result = await showDialog<PaymentType>(
      context: context,
      builder: (context) => _PaymentTypePickerDialog(
        paymentTypes: _paymentTypes,
        allowClear: true,
      ),
    );
    if (result != null) {
      await _onPaymentTypeFilterChanged(result.id == -1 ? null : result.id);
    }
  }

  void _startEdit(OrderModel order) {
    _proveOfPaymentController.text = order.proveOfPayment ?? '';

    setState(() {
      _editingOrderId = order.id;
      _selectedAccountId = order.accountId;
      _selectedPaymentTypeId = order.paymentTypeId;
      _paymentDateTime = order.paymentDate;
      _showingTable = false;
    });
  }

  void _startCreate() {
    _formKey.currentState?.reset();
    _proveOfPaymentController.clear();

    setState(() {
      _editingOrderId = null;
      _selectedAccountId = null;
      _selectedPaymentTypeId = null;
      _paymentDateTime = null;
      _showingTable = false;
    });
  }

  Future<void> _confirmDeleteOrder(OrderModel order) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.white,
        title: const Text('Delete order?', style: TextStyle(color: Color(0xFF212121))),
        content: Text(
          'This will permanently delete Order #${order.id}.',
          style: const TextStyle(color: Color(0xFF757575)),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      try {
        await OrdersApiService.deleteOrder(order.id);
        _loadOrders();
      } catch (e) {
        if (!mounted) return;
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Error: $e')));
      }
    }
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    if (_selectedAccountId == null) {
      _snack('Please select an account');
      return;
    }

    final proveOfPayment = _proveOfPaymentController.text.trim();

    setState(() => _isSubmitting = true);

    try {
      if (_editingOrderId == null) {
        final result = await OrdersApiService.createOrder(
          accountId: _selectedAccountId!,
          paymentTypeId: _selectedPaymentTypeId,
          paymentDateYMDT: _paymentDateTime == null
              ? null
              : _formatForApi(_paymentDateTime!),
          proveOfPayment: proveOfPayment.isEmpty ? null : proveOfPayment,
        );
        _snack(result['msg']?.toString() ?? 'Order created');
      } else {
        await OrdersApiService.updateOrder(
          orderId: _editingOrderId!,
          accountId: _selectedAccountId!,
          paymentTypeId: _selectedPaymentTypeId,
          paymentDateYMDT: _paymentDateTime == null
              ? null
              : _formatForApi(_paymentDateTime!),
          proveOfPayment: proveOfPayment.isEmpty ? null : proveOfPayment,
        );
        _snack('Order updated');
      }

      _startCreate();
      _loadOrders();
    } catch (e) {
      _snack('Error: $e');
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  InputDecoration _decoration(String label) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: Color(0xFF757575)),
      filled: true,
      fillColor: const Color(0xFFFAFAFA),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Color(0x33000000)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Color(0xFF5B4DFF), width: 1.6),
      ),
    );
  }

  // ---------------- build ----------------

  @override
  Widget build(BuildContext context) {
    if (_showingTable) {
      return _buildTableView();
    }
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (_editingOrderId != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Text(
                  'Editing Order ID: $_editingOrderId',
                  style: const TextStyle(
                    color: Color(0xFF5B4DFF),
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),

            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  child: InkWell(
                    onTap: _loadingAccounts ? null : _openAccountPicker,
                    child: InputDecorator(
                      decoration: _decoration('Account'),
                      child: Text(
                        _selectedAccountId == null
                            ? (_loadingAccounts
                                ? 'Loading...'
                                : 'Tap to select account')
                            : _accountNameFor(_selectedAccountId!),
                        style: const TextStyle(color: Color(0xFF212121)),
                      ),
                    ),
                  ),
                ),
                IconButton(
                  onPressed: _loadingAccounts ? null : _loadAccounts,
                  icon: _loadingAccounts
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Color(0xFF757575),
                          ),
                        )
                      : const Icon(Icons.refresh, color: Color(0xFF757575)),
                  tooltip: 'Refresh account list',
                ),
              ],
            ),
            const SizedBox(height: 16),

            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  child: InkWell(
                    onTap: _loadingPaymentTypes ? null : _openPaymentTypePicker,
                    child: InputDecorator(
                      decoration: _decoration('Payment Type'),
                      child: Text(
                        _selectedPaymentTypeId == null
                            ? (_loadingPaymentTypes
                                ? 'Loading...'
                                : 'Tap to select payment type')
                            : _paymentTypeNameFor(_selectedPaymentTypeId!),
                        style: const TextStyle(color: Color(0xFF212121)),
                      ),
                    ),
                  ),
                ),
                IconButton(
                  onPressed: _loadingPaymentTypes ? null : _loadPaymentTypes,
                  icon: _loadingPaymentTypes
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Color(0xFF757575),
                          ),
                        )
                      : const Icon(Icons.refresh, color: Color(0xFF757575)),
                  tooltip: 'Refresh payment type list',
                ),
              ],
            ),
            const SizedBox(height: 16),

            Row(
              children: [
                Expanded(
                  child: InkWell(
                    onTap: _pickPaymentDate,
                    child: InputDecorator(
                      decoration: _decoration('Payment Date/Time (optional)'),
                      child: Text(
                        _formatForDisplay(_paymentDateTime),
                        style: const TextStyle(color: Color(0xFF212121)),
                      ),
                    ),
                  ),
                ),
                if (_paymentDateTime != null)
                  IconButton(
                    icon: const Icon(Icons.clear, color: Color(0xFF757575)),
                    tooltip: 'Clear payment date',
                    onPressed: _clearPaymentDate,
                  ),
              ],
            ),
            const SizedBox(height: 16),

            TextFormField(
              controller: _proveOfPaymentController,
              style: const TextStyle(color: Color(0xFF212121)),
              decoration: _decoration('Proof of Payment (optional)'),
            ),
            const SizedBox(height: 16),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isSubmitting ? null : _submit,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF5B4DFF),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: _isSubmitting
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : Text(_editingOrderId == null ? 'Create Order' : 'Update Order'),
              ),
            ),
            const SizedBox(height: 12),

            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: _openTable,
                style: OutlinedButton.styleFrom(
                  foregroundColor: Color(0xFF212121),
                  side: const BorderSide(color: Color(0x33000000)),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: const Text('View / Manage Orders'),
              ),
            ),

            if (_editingOrderId != null) ...[
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: TextButton(
                  onPressed: _startCreate,
                  child: const Text('Cancel Edit / Create New Order'),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildTableView() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Row(
            children: [
              Expanded(
                child: InkWell(
                  onTap: _openPaymentTypeFilterPicker,
                  child: InputDecorator(
                    decoration: _decoration('Filter by Payment Type'),
                    child: Text(
                      _filterPaymentTypeId == null
                          ? 'All Payment Types -- tap to filter'
                          : _paymentTypeNameFor(_filterPaymentTypeId!),
                      style: const TextStyle(color: Color(0xFF212121)),
                    ),
                  ),
                ),
              ),
              if (_filterPaymentTypeId != null)
                IconButton(
                  icon: const Icon(Icons.clear, color: Color(0xFF757575)),
                  tooltip: 'Clear payment type filter',
                  onPressed: () => _onPaymentTypeFilterChanged(null),
                ),
              const SizedBox(width: 8),
              IconButton(
                icon: const Icon(Icons.refresh, color: Color(0xFF757575)),
                onPressed: _loadOrders,
              ),
              TextButton(
                onPressed: () => setState(() => _showingTable = false),
                child: const Text('Back'),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: TextField(
            controller: _orderSearchController,
            onChanged: _filterOrders,
            style: const TextStyle(color: Color(0xFF212121)),
            decoration: InputDecoration(
              hintText: 'Search by order ID, account ID, or account name',
              hintStyle: const TextStyle(color: Color(0xFF9E9E9E)),
              prefixIcon: const Icon(Icons.search, color: Color(0xFF9E9E9E)),
              enabledBorder: const UnderlineInputBorder(
                borderSide: BorderSide(color: Color(0x33000000)),
              ),
              focusedBorder: const UnderlineInputBorder(
                borderSide: BorderSide(color: Color(0xFF5B4DFF)),
              ),
            ),
          ),
        ),
        Expanded(
          child: _loadingOrders
              ? const Center(child: CircularProgressIndicator())
              : _filteredOrders.isEmpty
                  ? const Center(
                      child: Text(
                        'No orders found',
                        style: TextStyle(color: Color(0xFF9E9E9E)),
                      ),
                    )
                  : Material(
                      color: Colors.transparent,
                      child: ListView.builder(
                        itemCount: _filteredOrders.length,
                        itemBuilder: (context, index) {
                          final order = _filteredOrders[index];
                          return ListTile(
                            title: Text(
                              'Order #${order.id}',
                              style: const TextStyle(color: Color(0xFF212121)),
                            ),
                            subtitle: Text(
                              '${_accountNameFor(order.accountId)}  •  '
                              '${_paymentTypeNameFor(order.paymentTypeId)}  •  '
                              '${_formatForDisplay(order.paymentDate)}',
                              style: const TextStyle(color: Color(0xFF9E9E9E)),
                              overflow: TextOverflow.ellipsis,
                            ),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                  icon: const Icon(Icons.edit, color: Color(0xFF757575)),
                                  onPressed: () => _startEdit(order),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.delete, color: Colors.redAccent),
                                  onPressed: () => _confirmDeleteOrder(order),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
        ),
      ],
    );
  }
}

/// Lightweight searchable account picker, private to this file.
class _AccountPickerDialog extends StatefulWidget {
  final List<AccountModel> accounts;

  const _AccountPickerDialog({required this.accounts});

  @override
  State<_AccountPickerDialog> createState() => _AccountPickerDialogState();
}

class _AccountPickerDialogState extends State<_AccountPickerDialog> {
  final _searchController = TextEditingController();
  late List<AccountModel> _filtered;

  @override
  void initState() {
    super.initState();
    _filtered = widget.accounts;
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _onSearchChanged(String query) {
    final q = query.trim().toLowerCase();
    setState(() {
      _filtered = widget.accounts.where((a) {
        return q.isEmpty ||
            a.firstName.toLowerCase().contains(q) ||
            a.lastName.toLowerCase().contains(q) ||
            a.email.toLowerCase().contains(q) ||
            a.id.toString().contains(q);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.white,
      child: SizedBox(
        width: 400,
        height: 480,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: TextField(
                controller: _searchController,
                autofocus: true,
                onChanged: _onSearchChanged,
                style: const TextStyle(color: Color(0xFF212121)),
                decoration: const InputDecoration(
                  hintText: 'Search accounts',
                  hintStyle: TextStyle(color: Color(0xFF9E9E9E)),
                  prefixIcon: Icon(Icons.search, color: Color(0xFF9E9E9E)),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Color(0x33000000)),
                  ),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Color(0xFF5B4DFF)),
                  ),
                ),
              ),
            ),
            Expanded(
              child: _filtered.isEmpty
                  ? const Center(
                      child: Text(
                        'No accounts found',
                        style: TextStyle(color: Color(0xFF9E9E9E)),
                      ),
                    )
                  : ListView(
                      children: [
                        for (final account in _filtered)
                          ListTile(
                            title: Text(
                              '${account.firstName} ${account.lastName}',
                              style: const TextStyle(color: Color(0xFF212121)),
                            ),
                            subtitle: Text(
                              'ID: ${account.id}  •  ${account.email}',
                              style: const TextStyle(color: Color(0xFF9E9E9E)),
                            ),
                            onTap: () => Navigator.pop(context, account),
                          ),
                      ],
                    ),
            ),
            Padding(
              padding: const EdgeInsets.all(8),
              child: Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Cancel'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Lightweight searchable payment type picker, private to this file.
class _PaymentTypePickerDialog extends StatefulWidget {
  final List<PaymentType> paymentTypes;
  final bool allowClear;

  const _PaymentTypePickerDialog({
    required this.paymentTypes,
    this.allowClear = false,
  });

  @override
  State<_PaymentTypePickerDialog> createState() =>
      _PaymentTypePickerDialogState();
}

class _PaymentTypePickerDialogState extends State<_PaymentTypePickerDialog> {
  final _searchController = TextEditingController();
  late List<PaymentType> _filtered;

  @override
  void initState() {
    super.initState();
    _filtered = widget.paymentTypes;
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _onSearchChanged(String query) {
    final q = query.trim().toLowerCase();
    setState(() {
      _filtered = widget.paymentTypes.where((t) {
        return q.isEmpty ||
            t.paymentTypeName.toLowerCase().contains(q) ||
            t.id.toString().contains(q);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.white,
      child: SizedBox(
        width: 400,
        height: 480,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: TextField(
                controller: _searchController,
                autofocus: true,
                onChanged: _onSearchChanged,
                style: const TextStyle(color: Color(0xFF212121)),
                decoration: const InputDecoration(
                  hintText: 'Search payment types',
                  hintStyle: TextStyle(color: Color(0xFF9E9E9E)),
                  prefixIcon: Icon(Icons.search, color: Color(0xFF9E9E9E)),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Color(0x33000000)),
                  ),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Color(0xFF5B4DFF)),
                  ),
                ),
              ),
            ),
            Expanded(
              child: _filtered.isEmpty
                  ? const Center(
                      child: Text(
                        'No payment types found',
                        style: TextStyle(color: Color(0xFF9E9E9E)),
                      ),
                    )
                  : ListView(
                      children: [
                        if (widget.allowClear)
                          ListTile(
                            leading: const Icon(Icons.clear, color: Color(0xFF757575)),
                            title: const Text(
                              'All Payment Types',
                              style: TextStyle(color: Color(0xFF212121)),
                            ),
                            onTap: () => Navigator.pop(
                              context,
                              PaymentType(id: -1, paymentTypeName: 'All Payment Types'),
                            ),
                          ),
                        for (final type in _filtered)
                          ListTile(
                            title: Text(
                              type.paymentTypeName,
                              style: const TextStyle(color: Color(0xFF212121)),
                            ),
                            subtitle: Text(
                              'ID: ${type.id}',
                              style: const TextStyle(color: Color(0xFF9E9E9E)),
                            ),
                            onTap: () => Navigator.pop(context, type),
                          ),
                      ],
                    ),
            ),
            Padding(
              padding: const EdgeInsets.all(8),
              child: Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Cancel'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
